﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LCRDice.Infrastructure
{
    public interface IGame
    {

        void Play();
        void SetNumberPlayers(int numberPlayers);

        int GetNumberPlayers();
    }
}
