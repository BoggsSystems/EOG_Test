﻿using LCRDice.Infrastructure;
using System;
using System.Collections.Generic;
using System.Text;

namespace LCRDice.Models
{
    public class LCRDiceGame : IGame
    {

        #region Private members
        private int numberOfPlayers;
        private Random rand = new Random();
        private List<Player> playersList = new List<Player>();
        private LinkedList<Player> playersLinkedList;
        private int potChipCount = 0;
        private int turnCount = 0;

        private int NumberOfPlayers { get => numberOfPlayers; set => numberOfPlayers = value; }

        #endregion

        #region Properties
        public int TurnCount { get => turnCount; set => turnCount = value; }
        #endregion

        #region Methods
        void IGame.Play()
        {
            // Setup Players
            for (int i = 0; i < numberOfPlayers; i++)
            {
                playersList.Add(new Player(i+1));
            }

            playersLinkedList = new LinkedList<Player>(playersList);

            LinkedListNode<Player> currentPlayer = playersLinkedList.First;

            while (true)
            {
                turnCount += 1;

                if (currentPlayer.Value.Chips > 0)
                {
                    int numberRolls;

                    if(currentPlayer.Value.Chips >= 3)
                    {
                        numberRolls = 3;
                    }
                    else
                    {
                        numberRolls = currentPlayer.Value.Chips;
                    }


                    for (int i = 0; i < numberRolls; i++)
                    {
                        Roll(currentPlayer);
                    }

                    bool win = IsWin();

                    if (win)
                    {
                        break;
                    }
                    else
                    {
                        if (currentPlayer.Next != null)
                        {
                            currentPlayer = currentPlayer.Next;
                        }
                        else
                        {
                            currentPlayer = NextPlayer(currentPlayer);
                        }
                    };
                }
                else
                {
                    currentPlayer = NextPlayer(currentPlayer);
                };


            }
        }

        private LinkedListNode<Player> NextPlayer(LinkedListNode<Player> node)
        {
            if (node.Next != null)
            {
                return node.Next;
            }
            else
            {
                return playersLinkedList.First;
            }
        }

        private void Roll(LinkedListNode<Player> playerNode)
        {
            var x = rand.Next(1, 6);

            if (x < 4)
            {
                return;
            }
            else if (x == 4)  // Left
            {
                DecrementChips(playerNode.Value);

                if (playerNode.Previous != null)
                {
                    IncrementChips(playerNode.Previous.Value);
                }
                else
                {
                    IncrementChips(playersLinkedList.Last.Value);
                }
            }
            else if (x == 5) // Center
            {
                DecrementChips(playerNode.Value);
                potChipCount += 1;
            }
            else if (x == 6)  // Right
            {
                DecrementChips(playerNode.Value);

                if (playerNode.Next.Value != null)
                {
                    IncrementChips(playerNode.Next.Value);
                }
                else
                {
                    IncrementChips(playersLinkedList.First.Value);
                }

                IncrementChips(playerNode.Next.Value);
            }

        }

        private bool IsWin()
        {
            int positiveChipCount = 0;

            foreach(var item in playersList)
            {
                if (item.Chips > 0)
                {
                    positiveChipCount += 1;
                }
            }

            return positiveChipCount == 1;

        }


        public void DecrementChips(Player player)
        {
            player.Chips -= 1;
        }

        public void IncrementChips(Player player)
        {
            player.Chips += 1;
        }

        void IGame.SetNumberPlayers(int numberPlayers)
        {
            this.NumberOfPlayers = numberPlayers;
        }

        int IGame.GetNumberPlayers()
        {
            return this.numberOfPlayers;
        }

        #endregion
    }
}

