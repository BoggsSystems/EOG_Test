﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LCRDice.Models
{
    public class Player
    {
        private int chips =  3;
        private string name;

        public int Chips { get => chips; set => chips = value; }
        public string Name { get => name; set => name = value; }

        public Player() { }
        public Player(int playerNumber)
        {
            this.Name = "Player " + playerNumber.ToString();
        }
    }
}
