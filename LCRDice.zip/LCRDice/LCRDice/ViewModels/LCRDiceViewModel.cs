﻿using LCRDice.Infrastructure;
using LCRDice.Models;
using Prism.Commands;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Input;

namespace LCRDice.ViewModels
{
    public class LCRDiceViewModel : ViewModelBase
    {

        #region Private members

        private int numberGames = 1;
        private int numberPlayers = 3;
        private string resultsMin;
        private string resultsAvg;
        private string resultsMax;
        private List<int> gameResults;
        private IGame LCRDiceGame;

        #endregion


        #region Commands

        public DelegateCommand<object> NewGameCommand { get; private set; }
        public DelegateCommand<object> SetNumberPlayersCommand { get; private set; }
        public DelegateCommand<object> SetNumberGamesCommand { get; private set; }

        #endregion


        #region Properties

        public string ResultsMin
        {
            get { return resultsMin; }

            set
            {
                resultsMin = value;
                OnPropertyChanged("ResultsMin");
            }
        }

        public string ResultsAvg
        {
            get { return resultsAvg; }

            set
            {
                resultsAvg = value;
                OnPropertyChanged("ResultsAvg");
            }
        }

        public string ResultsMax
        {
            get { return resultsMax; }

            set
            {
                resultsMax = value;
                OnPropertyChanged("ResultsMax");
            }
        }

        public int NumberPlayers
        {
            get { return numberPlayers; }

            set
            {
                numberPlayers = value;
                NewGameCommand.RaiseCanExecuteChanged();
            }
        }



        public int NumberGames
        {
            get { return numberGames; }

            set
            {
                numberGames = value;
                NewGameCommand.RaiseCanExecuteChanged();
            }
        }


        #endregion


        #region Constructors

        public LCRDiceViewModel()
        {
            
            gameResults = new List<int>();
            NewGameCommand = new DelegateCommand<object>(NewGame, CanNewGame);
            SetNumberPlayersCommand = new DelegateCommand<object>(SetNumberPlayers, CanSetNumberPlayers);
            SetNumberGamesCommand = new DelegateCommand<object>(SetNumberGames, CanSetNumberGames);
        }

        #endregion


        #region Methods
        void NewGame(object parameter)
        {
            gameResults.Clear();

            for (int i = 0; i < numberGames; i++)
            {
                LCRDiceGame = new LCRDiceGame();
                LCRDiceGame.SetNumberPlayers(numberPlayers);
                LCRDiceGame.Play();
                gameResults.Add((LCRDiceGame as LCRDiceGame).TurnCount);
            }

            ResultsMax = GetMaxTurns().ToString();
            ResultsMin = GetMinTurns().ToString();
            ResultsAvg = GetAvgTurns().ToString();
        }

        int GetMaxTurns()
        {
            return gameResults.Max();
        }

        int GetMinTurns()
        {
            return gameResults.Min();
        }

        double GetAvgTurns()
        {
            return gameResults.Average();
        }



        bool CanNewGame(object parameter)
        {
            return NumberPlayers >= 3 && NumberGames > 0;
        }


        void SetNumberPlayers(object parameter)
        {
            LCRDiceGame.SetNumberPlayers((int)parameter);
        }

        bool CanSetNumberPlayers(object parameter)
        {
            return true;
        }

        void SetNumberGames(object parameter)
        {
            this.numberGames = (int)parameter;
        }

        bool CanSetNumberGames(object parameter)
        {
            return true;
        }

        #endregion
    }
}
